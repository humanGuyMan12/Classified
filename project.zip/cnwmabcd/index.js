// javascript
 
 let codeConsole = document.getElementById("codeEl")
 let linkVar = document.getElementById("linkEl")

function digitCode(Code) {
Code = prompt("Enter 5 Digit Code");
if (Code == 40631) {
    alert("Please click the link that appeared on your screen") 
    codeConsole.innerText = Code
    linkVar.innerText = "Click Here"
}
else {
   alert("Incorrect Code") 
}}